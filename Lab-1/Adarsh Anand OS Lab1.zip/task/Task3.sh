# how many lines of a file contain a given word
grep -c $2 $1