echo "HELLO-WORLD"

# C program to display “HELLO - WORLD”
# #include <stdio.h>
# int main()
# {
# printf("HELLO - WORLD\n");
# }