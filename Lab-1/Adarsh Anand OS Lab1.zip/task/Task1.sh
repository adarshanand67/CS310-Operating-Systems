who>myfile1
more myfile1